package thareesha.campusTalk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusTalkApplicationTests {

	@Test
	void contextLoads() {
	}

}
